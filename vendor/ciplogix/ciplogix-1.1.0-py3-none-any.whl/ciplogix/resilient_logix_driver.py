"""
ResilientLogixDriver - EnhancedLogixDriver with built-in retry logic

Provides automatic retries with exponential backoff for transient
communication failures.  Retry parameters are configurable; set
max_retries=0 to disable retries and behave identically to
EnhancedLogixDriver.

Backwards-compatible: still accepts (and warns on) the deprecated
``reconnection_config`` kwarg.
"""

import logging
import time
import warnings
from typing import Any, Optional, Sequence, Union

from .enhanced_logix_driver import EnhancedLogixDriver, FragmentationStats
from .exceptions import CircuitBreakerError, CommError, RateLimitError
from .tag import Tag

logger = logging.getLogger(__name__)


class ConnectionLostError(CommError):
    """
    Deprecated: No longer raised by the driver.

    Kept for backwards compatibility with existing exception handlers.
    """


class ReconnectionConfig:
    """
    Deprecated: Use ResilientLogixDriver's retry kwargs instead.
    """

    def __init__(self, **kwargs: Any) -> None:
        warnings.warn(
            "ReconnectionConfig is deprecated. "
            "Pass max_retries / retry_delay to ResilientLogixDriver instead.",
            DeprecationWarning,
            stacklevel=2,
        )


# Exceptions that should NOT trigger a retry (they indicate a logic /
# configuration problem, not a transient network issue).
_NON_RETRYABLE = (RateLimitError, CircuitBreakerError, KeyboardInterrupt)


class ResilientLogixDriver(EnhancedLogixDriver):
    """
    EnhancedLogixDriver with automatic retry on transient failures.

    Args (in addition to all EnhancedLogixDriver args):
        max_retries (int): Maximum retry attempts (default: 3, 0 = no retry).
        retry_delay (float): Initial delay in seconds between retries (default: 1.0).
        retry_backoff (float): Multiplier applied to delay after each retry (default: 2.0).
        retry_max_delay (float): Cap on retry delay in seconds (default: 30.0).

    Example::

        with ResilientLogixDriver('192.168.1.10', max_retries=5) as plc:
            value = plc.read('MyTag')   # auto-retries on transient errors
    """

    def __init__(
        self,
        *args: Any,
        reconnection_config: Optional[Any] = None,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        retry_backoff: float = 2.0,
        retry_max_delay: float = 30.0,
        **kwargs: Any,
    ) -> None:
        if reconnection_config is not None:
            warnings.warn(
                "reconnection_config is ignored. "
                "Use max_retries / retry_delay kwargs instead.",
                DeprecationWarning,
                stacklevel=2,
            )

        self._max_retries = max_retries
        self._retry_delay = retry_delay
        self._retry_backoff = retry_backoff
        self._retry_max_delay = retry_max_delay

        super().__init__(*args, **kwargs)

        if max_retries > 0:
            logger.info(
                "ResilientLogixDriver: retries=%d, delay=%.1fs, backoff=%.1fx",
                max_retries, retry_delay, retry_backoff,
            )

    # -- retry wrapper ---------------------------------------------------

    def _with_retry(self, func, *args, **kwargs):
        """Execute *func* with retry logic on transient failures."""
        last_error: Optional[Exception] = None
        delay = self._retry_delay

        for attempt in range(self._max_retries + 1):
            try:
                return func(*args, **kwargs)
            except _NON_RETRYABLE:
                raise
            except Exception as e:
                last_error = e
                if attempt < self._max_retries:
                    logger.warning(
                        "Attempt %d/%d failed (%s), retrying in %.1fs",
                        attempt + 1, self._max_retries + 1, e, delay,
                    )
                    time.sleep(delay)
                    delay = min(delay * self._retry_backoff, self._retry_max_delay)

        raise last_error  # type: ignore[misc]

    # -- overrides -------------------------------------------------------

    def read(self, *tags: str) -> Union[Tag, Sequence[Tag]]:
        if self._max_retries > 0:
            return self._with_retry(super().read, *tags)
        return super().read(*tags)

    def write(self, *tags_values) -> Union[Tag, Sequence[Tag]]:
        if self._max_retries > 0:
            return self._with_retry(super().write, *tags_values)
        return super().write(*tags_values)


# Convenience alias — canonical location (Issue 2)
LogixDriver = ResilientLogixDriver

__all__ = [
    "ResilientLogixDriver",
    "LogixDriver",
    "ReconnectionConfig",
    "ConnectionLostError",
]
