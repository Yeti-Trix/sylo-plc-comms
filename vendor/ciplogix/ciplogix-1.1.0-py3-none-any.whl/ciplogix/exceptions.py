"""
CIPLogix Exception Classes

Extended exception hierarchy for better error handling and debugging.
"""


class CIPLogixError(Exception):
    """Base exception for all CIPLogix errors."""
    pass


class CommError(CIPLogixError):
    """Communication error (socket, network, connection issues)."""
    pass


class ResponseError(CIPLogixError):
    """Error in PLC response or response processing."""
    pass


class RequestError(CIPLogixError):
    """Error building or validating request."""
    pass


class RateLimitError(CIPLogixError):
    """
    Rate limit exceeded - request rejected for PLC protection.
    
    This error indicates the application is sending requests too quickly
    and needs to back off to prevent PLC buffer saturation.
    """
    pass


class CircuitBreakerError(CIPLogixError):
    """
    Circuit breaker is OPEN - PLC is unavailable.
    
    Too many consecutive failures detected. Circuit breaker
    will automatically retry after timeout period.
    """
    pass


class BufferSaturationError(CommError):
    """
    PLC buffer saturation detected (CIP error code 0x02).
    
    This is a CRITICAL error indicating the PLC's communication buffer
    is full. Application must significantly back off.
    """
    pass


class ConnectionPoolExhaustedError(CommError):
    """All connections in pool are in use or maximum limit reached."""
    pass


class TagNotFoundError(RequestError):
    """Requested tag does not exist in PLC."""
    pass


class FragmentationRequiredError(RequestError):
    """Data too large for single packet - fragmentation required."""
    pass

