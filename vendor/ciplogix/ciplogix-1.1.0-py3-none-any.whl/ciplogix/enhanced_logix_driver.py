"""
Enhanced LogixDriver with Fragmentation Support

This module wraps pycomm3's LogixDriver and adds:
1. Automatic fragmentation for large arrays
2. Fragmentation planning infrastructure
3. Adaptive fragment sizing
4. Resource protection

Usage:
    from ciplogix import EnhancedLogixDriver
    
    with EnhancedLogixDriver('10.1.200.5') as plc:
        # Automatically handles large arrays with fragmentation
        large_array = plc.read('Test_Large_Dint_Array{1000}')
        
        # Fragmentation settings are configurable here
        very_large = plc.read('Huge_Array{10000}')
"""

import logging
import socket as _socket_mod
import time
from typing import Union, Sequence, Optional, Any
from dataclasses import dataclass

try:
    from pycomm3 import LogixDriver as PycommLogixDriver
    from pycomm3.tag import Tag as PycommTag
except ImportError:
    raise ImportError(
        "pycomm3 is required. Install with: pip install pycomm3"
    )

from .fragmentation import (
    FragmentationConfig,
    FragmentPlan,
    PipelinedFragmentExecutor,
    needs_fragmentation,
)
from .resource_monitor import PLCResourceMonitor
from .socket_ import apply_socket_optimizations
from .circuit_breaker import CircuitBreaker
from .tag import Tag
from .exceptions import CommError, CircuitBreakerError, RateLimitError

logger = logging.getLogger(__name__)


@dataclass
class FragmentationStats:
    """Statistics from fragmented operations"""
    was_fragmented: bool = False
    fragment_count: int = 0
    total_bytes: int = 0
    duration_ms: float = 0.0
    used_pipelining: bool = False


class EnhancedLogixDriver(PycommLogixDriver):
    """
    Enhanced LogixDriver with automatic fragmentation support.
    
    This class extends pycomm3's LogixDriver with:
    - Automatic fragmentation for large arrays (>500 bytes)
    - Fragmentation configuration and tracking
    - Adaptive fragment sizing (adjusts to PLC capabilities)
    - Detailed fragmentation statistics
    
    100% compatible with pycomm3 API - drop-in replacement!
    
    Example:
        # Just replace LogixDriver with EnhancedLogixDriver
        with EnhancedLogixDriver('192.168.1.10') as plc:
            # Small arrays work as normal
            small = plc.read('SmallArray{100}')
            
            # Large arrays automatically use fragmentation
            large = plc.read('LargeArray{1000}')  # Now works!
            
            # Check if fragmentation was used
            if plc.last_fragmentation_stats.was_fragmented:
                print(f"Used {plc.last_fragmentation_stats.fragment_count} fragments")
    """
    
    def __init__(self, *args, **kwargs):
        """
        Initialize Enhanced LogixDriver.

        All pycomm3 parameters are supported. Additional parameters:

        Args:
            enable_fragmentation (bool): Enable automatic fragmentation (default: True)
            frag_max_packet_size (int): Max packet size in bytes (default: 4002)
            frag_enable_pipelining (bool): Enable pipelining in fragmentation config
            frag_enable_adaptive (bool): Enable adaptive sizing (default: True)
            frag_max_concurrent (int): Max concurrent fragments (default: 4)
            enable_throttling (bool): Enable rate limiting (default: True)
            max_rps (int): Maximum requests per second when throttling (default: 50)
            block_on_rate_limit (bool): If True, wait when limit hit; if False, raise (default: True)
            optimize_socket (bool): Apply TCP tuning after connect (default: True)
            enable_circuit_breaker (bool): Wrap read/write with circuit breaker (default: False)
            cb_failure_threshold (int): Failures before circuit opens (default: 5)
            cb_timeout (int): Seconds before retry after circuit opens (default: 60)
        """
        # Extract fragmentation config
        self._enable_fragmentation = kwargs.pop('enable_fragmentation', True)

        # Extract rate-limiting config
        enable_throttling = kwargs.pop('enable_throttling', True)
        max_rps = kwargs.pop('max_rps', 50)
        self._block_on_rate_limit = kwargs.pop('block_on_rate_limit', True)

        # Socket optimisation flag
        self._optimize_socket = kwargs.pop('optimize_socket', True)

        # Circuit breaker config
        enable_cb = kwargs.pop('enable_circuit_breaker', False)
        cb_threshold = kwargs.pop('cb_failure_threshold', 5)
        cb_timeout = kwargs.pop('cb_timeout', 60)

        # Create fragmentation configuration
        self.frag_config = FragmentationConfig(
            max_packet_size=kwargs.pop('frag_max_packet_size', 4002),
            initial_fragment_size=kwargs.pop('frag_initial_size', 480),
            max_concurrent_fragments=kwargs.pop('frag_max_concurrent', 4),
            enable_pipelining=kwargs.pop('frag_enable_pipelining', True),
            enable_adaptive_sizing=kwargs.pop('frag_enable_adaptive', True),
        )

        # Initialize pycomm3 driver
        super().__init__(*args, **kwargs)

        # Rate limiting
        self._resource_monitor: Optional[PLCResourceMonitor] = None
        if enable_throttling:
            ip = (args[0] if args else "unknown").split("/")[0]
            self._resource_monitor = PLCResourceMonitor(plc_ip=ip, max_rps=max_rps)

        # Circuit breaker (off by default to preserve existing behaviour)
        self._circuit_breaker: Optional[CircuitBreaker] = None
        if enable_cb:
            self._circuit_breaker = CircuitBreaker(
                failure_threshold=cb_threshold,
                timeout=cb_timeout,
                expected_exception=Exception,
            )

        self._frag_executor = None

        # Track fragmentation statistics
        self.last_fragmentation_stats = FragmentationStats()
        self._total_fragmented_operations = 0

        logger.info(
            "Enhanced LogixDriver initialized: "
            "fragmentation=%s, max_packet_size=%s, throttling=%s, "
            "socket_opt=%s, circuit_breaker=%s",
            'enabled' if self._enable_fragmentation else 'disabled',
            self.frag_config.max_packet_size,
            'enabled' if self._resource_monitor else 'disabled',
            'enabled' if self._optimize_socket else 'disabled',
            'enabled' if self._circuit_breaker else 'disabled',
        )
    
    # -- socket optimisation (Issue 3) ------------------------------------

    def open(self, *args, **kwargs):
        """Open connection and apply TCP optimizations if enabled."""
        result = super().open(*args, **kwargs)
        if self._optimize_socket:
            self._apply_socket_optimizations()
        return result

    def _apply_socket_optimizations(self) -> None:
        """Apply TCP_NODELAY, larger buffers, and keepalive to pycomm3's socket."""
        try:
            raw_sock = None
            if hasattr(self, '_sock'):
                candidate = self._sock
                if isinstance(candidate, _socket_mod.socket):
                    raw_sock = candidate
                elif hasattr(candidate, '_socket'):
                    raw_sock = candidate._socket
                elif hasattr(candidate, 'socket'):
                    raw_sock = candidate.socket

            if raw_sock is None:
                logger.debug("Could not locate raw socket for TCP tuning")
                return

            apply_socket_optimizations(raw_sock)
            logger.info("Applied TCP optimizations to PLC socket")
        except Exception as e:
            logger.warning("Socket optimizations failed (non-fatal): %s", e)

    # -- read / write ----------------------------------------------------

    def read(self, *tags: str) -> Union[Tag, Sequence[Tag]]:
        """
        Read tag(s) from PLC with automatic fragmentation support.
        
        This method automatically detects when fragmentation is needed and
        handles it transparently. For arrays >500 bytes, multiple read requests
        are made and results are reassembled.
        
        Args:
            *tags: One or more tag names to read
        
        Returns:
            Single Tag if one tag requested, Sequence[Tag] if multiple
        
        Examples:
            # Single tag
            tag = plc.read('MyTag')
            
            # Multiple tags
            tags = plc.read('Tag1', 'Tag2', 'Tag3')
            
            # Large array (auto-fragmented)
            large = plc.read('LargeArray{1000}')
        """
        self._check_rate_limit()

        if self._circuit_breaker:
            return self._circuit_breaker.call(self._do_read, *tags)
        return self._do_read(*tags)

    def _do_read(self, *tags: str) -> Union[Tag, Sequence[Tag]]:
        """Inner read logic, separated so circuit breaker can wrap it."""
        # Reset stats
        self.last_fragmentation_stats = FragmentationStats()

        if not self._enable_fragmentation or len(tags) > 1:
            result = super().read(*tags)
            self._record_monitor_success()
            return result

        tag_name = tags[0]
        return self._read_with_fragmentation(tag_name)
    
    def _read_with_fragmentation(self, tag_name: str) -> Tag:
        """
        Read a single tag with automatic fragmentation if needed.
        
        Args:
            tag_name: Tag to read
            
        Returns:
            Tag with data or error
        """
        start_time = time.perf_counter()
        
        try:
            # Try standard read first
            result = super().read(tag_name)
            
            # Check for "Insufficient Packet Space" error
            if isinstance(result, PycommTag) and result.error:
                if 'Insufficient Packet Space' in str(result.error):
                    logger.info(
                        f"Tag '{tag_name}' requires fragmentation "
                        f"(error: {result.error})"
                    )
                    # Try fragmented read
                    return self._read_fragmented(tag_name, start_time)
            
            # Standard read succeeded
            duration_ms = (time.perf_counter() - start_time) * 1000
            self.last_fragmentation_stats = FragmentationStats(
                was_fragmented=False,
                fragment_count=1,
                duration_ms=duration_ms
            )
            
            # Convert to our Tag type if needed
            return self._convert_tag(result)
            
        except Exception as e:
            logger.error(f"Read failed for '{tag_name}': {e}")
            duration_ms = (time.perf_counter() - start_time) * 1000
            self.last_fragmentation_stats.duration_ms = duration_ms
            return Tag(tag_name, None, error=str(e))
    
    def _read_fragmented(self, tag_name: str, start_time: float) -> Tag:
        """
        Read a tag using fragmentation (for large arrays).
        
        Args:
            tag_name: Tag to read
            start_time: Start time for stats
            
        Returns:
            Tag with reassembled data or error
        """
        try:
            # Parse tag name to get array specification
            # e.g., "MyArray{100}" -> name="MyArray", count=100
            base_name, element_count = self._parse_array_tag(tag_name)
            
            # Get tag metadata
            tag_info = self.get_tag_info(base_name)
            if not tag_info:
                return Tag(tag_name, None, error="Tag not found")
            
            # Calculate total size
            element_size = self._get_element_size(tag_info['data_type'])
            total_bytes = element_size * element_count
            
            logger.info(
                f"Fragmenting read: {tag_name} = {element_count} elements "
                f"× {element_size} bytes = {total_bytes} bytes"
            )
            
            # Create fragmentation plan
            plan = FragmentPlan(
                total_size=total_bytes,
                element_size=element_size,
                config=self.frag_config
            )
            
            fragments = plan.get_fragments()
            logger.debug(f"Created plan with {len(fragments)} fragments")
            
            # Read fragments sequentially (pycomm3 is synchronous)
            all_data = []
            for i, fragment in enumerate(fragments):
                # Calculate element range for this fragment
                start_element = fragment.offset // element_size
                num_elements = fragment.size // element_size
                
                # Build tag name with element range
                frag_tag = f"{base_name}[{start_element}]{{{num_elements}}}"
                
                logger.debug(
                    f"Reading fragment {i+1}/{len(fragments)}: "
                    f"{frag_tag} (offset={fragment.offset}, size={fragment.size})"
                )
                
                # Read this fragment
                frag_result = super().read(frag_tag)
                
                if isinstance(frag_result, PycommTag) and frag_result.error:
                    error_msg = f"Fragment {i+1} failed: {frag_result.error}"
                    logger.error(error_msg)
                    duration_ms = (time.perf_counter() - start_time) * 1000
                    self.last_fragmentation_stats = FragmentationStats(
                        was_fragmented=True,
                        fragment_count=i + 1,
                        total_bytes=total_bytes,
                        duration_ms=duration_ms,
                        used_pipelining=False
                    )
                    return Tag(tag_name, None, error=error_msg)
                
                # Collect fragment data
                if isinstance(frag_result, PycommTag):
                    if isinstance(frag_result.value, list):
                        all_data.extend(frag_result.value)
                    else:
                        all_data.append(frag_result.value)
            
            # Success!
            duration_ms = (time.perf_counter() - start_time) * 1000
            self.last_fragmentation_stats = FragmentationStats(
                was_fragmented=True,
                fragment_count=len(fragments),
                total_bytes=total_bytes,
                duration_ms=duration_ms,
                used_pipelining=False  # Sequential for now
            )
            self._total_fragmented_operations += 1
            
            logger.info(
                f"✅ Fragmented read complete: {tag_name} = "
                f"{len(all_data)} elements in {duration_ms:.2f}ms "
                f"({len(fragments)} fragments)"
            )
            
            return Tag(tag_name, all_data, error=None)
            
        except Exception as e:
            logger.error(f"Fragmented read failed: {e}")
            duration_ms = (time.perf_counter() - start_time) * 1000
            self.last_fragmentation_stats.duration_ms = duration_ms
            return Tag(tag_name, None, error=str(e))
    
    def _parse_array_tag(self, tag_name: str) -> tuple:
        """
        Parse array tag specification.
        
        Examples:
            "MyArray{100}" -> ("MyArray", 100)
            "MyArray[10]{50}" -> ("MyArray[10]", 50)
        
        Args:
            tag_name: Tag name with optional array spec
            
        Returns:
            (base_name, element_count)
        """
        if '{' in tag_name and '}' in tag_name:
            # Extract element count from {count}
            base_name = tag_name[:tag_name.rindex('{')]
            count_str = tag_name[tag_name.rindex('{')+1:tag_name.rindex('}')]
            element_count = int(count_str)
            return base_name, element_count
        else:
            # No array spec - read single element
            return tag_name, 1
    
    def _get_element_size(self, data_type: str) -> int:
        """
        Get size in bytes for a data type.
        
        Args:
            data_type: PLC data type name
            
        Returns:
            Size in bytes
        """
        # Standard sizes
        SIZE_MAP = {
            'BOOL': 1,
            'SINT': 1,
            'INT': 2,
            'DINT': 4,
            'LINT': 8,
            'REAL': 4,
            'LREAL': 8,
            'STRING': 88,  # STRING is 88 bytes (4 len + 84 data)
        }
        
        # Check if it's in the map
        data_type_upper = data_type.upper() if data_type else 'DINT'
        return SIZE_MAP.get(data_type_upper, 4)  # Default to 4 (DINT)
    
    def _convert_tag(self, pycomm_tag: PycommTag) -> Tag:
        """
        Convert pycomm3 Tag to our Tag type.
        
        Args:
            pycomm_tag: pycomm3 Tag object
            
        Returns:
            Our Tag object
        """
        if isinstance(pycomm_tag, PycommTag):
            return Tag(
                tag=pycomm_tag.tag,
                value=pycomm_tag.value,
                type=pycomm_tag.type,
                error=pycomm_tag.error
            )
        return pycomm_tag
    
    def write(self, *tags_values) -> Union[Tag, Sequence[Tag]]:
        """
        Write tag(s) to PLC.
        
        Currently uses standard pycomm3 write. Fragmented writes can be
        added in a future version if needed.
        
        Args:
            *tags_values: (tag, value) tuples
            
        Returns:
            Single Tag if one write, Sequence[Tag] if multiple
        """
        self._check_rate_limit()

        if self._circuit_breaker:
            return self._circuit_breaker.call(self._do_write, *tags_values)
        return self._do_write(*tags_values)

    def _do_write(self, *tags_values) -> Union[Tag, Sequence[Tag]]:
        """Inner write logic, separated so circuit breaker can wrap it."""
        result = super().write(*tags_values)
        self._record_monitor_success()
        return result
    
    def get_fragmentation_stats(self) -> dict:
        """
        Get comprehensive fragmentation statistics.
        
        Returns:
            Dictionary with fragmentation metrics
        """
        return {
            'last_operation': {
                'was_fragmented': self.last_fragmentation_stats.was_fragmented,
                'fragment_count': self.last_fragmentation_stats.fragment_count,
                'total_bytes': self.last_fragmentation_stats.total_bytes,
                'duration_ms': self.last_fragmentation_stats.duration_ms,
                'used_pipelining': self.last_fragmentation_stats.used_pipelining,
            },
            'total_fragmented_operations': self._total_fragmented_operations,
            'config': {
                'enabled': self._enable_fragmentation,
                'max_packet_size': self.frag_config.max_packet_size,
                'pipelining_enabled': self.frag_config.enable_pipelining,
                'adaptive_sizing': self.frag_config.enable_adaptive_sizing,
            }
        }
    
    def _check_rate_limit(self) -> None:
        """Enforce rate limiting if throttling is enabled."""
        if self._resource_monitor:
            if self._block_on_rate_limit:
                self._resource_monitor.wait_for_rate_limit()
            else:
                self._resource_monitor.check_rate_limit()

    def _record_monitor_success(self) -> None:
        """Record a successful operation for the resource monitor."""
        if self._resource_monitor:
            self._resource_monitor.record_success()

    def _record_monitor_error(self, error: Exception) -> None:
        """Record a failed operation for the resource monitor."""
        if self._resource_monitor:
            self._resource_monitor.record_error(error)

    def get_monitor_stats(self) -> dict | None:
        """
        Get resource monitoring statistics.

        Returns:
            Dict with rate limiting stats or None if throttling is disabled
        """
        if self._resource_monitor:
            return self._resource_monitor.get_stats()
        return None

    def get_circuit_breaker_stats(self) -> dict | None:
        """Get circuit breaker statistics, or None if disabled."""
        if self._circuit_breaker:
            return self._circuit_breaker.get_stats()
        return None

    def __repr__(self):
        return (
            f"EnhancedLogixDriver("
            f"connected={self.connected}, "
            f"fragmentation={'enabled' if self._enable_fragmentation else 'disabled'}, "
            f"fragmented_ops={self._total_fragmented_operations})"
        )


__all__ = ['EnhancedLogixDriver', 'FragmentationStats']

