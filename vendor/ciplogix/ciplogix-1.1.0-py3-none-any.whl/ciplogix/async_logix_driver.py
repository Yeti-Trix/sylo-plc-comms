"""
AsyncLogixDriver - Async/Await PLC Communication

Wraps EnhancedLogixDriver with asyncio, running blocking operations in a
dedicated thread executor. Provides:
- Non-blocking I/O for async applications
- Semaphore limits concurrent requests (prevents PLC overload)
- Automatic rate limiting
- Fragmentation support (via EnhancedLogixDriver)
"""

import asyncio
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, List, Optional, Sequence, Union

from .enhanced_logix_driver import EnhancedLogixDriver, FragmentationStats
from .exceptions import CommError, RateLimitError
from .resource_monitor import PLCResourceMonitor
from .tag import Tag

logger = logging.getLogger(__name__)


class AsyncLogixDriver:
    """
    Async/await PLC driver with automatic resource protection.

    Wraps EnhancedLogixDriver; blocking operations run in a single-thread
    executor to avoid blocking the event loop. Serialized driver access
    ensures thread safety.

    Usage:
        async def main():
            async with AsyncLogixDriver('192.168.1.10') as plc:
                tag = await plc.read_async('MyTag')
                tags = await plc.read_many_async(['Tag1', 'Tag2', 'Tag3'])

        asyncio.run(main())
    """

    def __init__(
        self,
        path: str,
        max_concurrent_requests: int = 3,
        min_request_interval: float = 0.01,
        max_rps: int = 50,
        init_tags: bool = True,
        **kwargs: Any,
    ) -> None:
        """
        Initialize async driver with safety limits.

        Args:
            path: PLC path (IP or IP/slot)
            max_concurrent_requests: Max simultaneous requests (default: 3)
            min_request_interval: Min seconds between requests (default: 0.01)
            max_rps: Maximum sustained requests per second (default: 50)
            init_tags: Upload tag list on connect (default: True)
            **kwargs: Additional EnhancedLogixDriver parameters

        Raises:
            CommError: If connection fails
        """
        self.path = path
        self.max_concurrent_requests = max_concurrent_requests
        self.min_request_interval = min_request_interval
        self._init_tags = init_tags
        self._driver_kwargs = kwargs

        self._driver: Optional[EnhancedLogixDriver] = None
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="ciplogix_async")
        self._closed = False

        self._semaphore = asyncio.Semaphore(max_concurrent_requests)

        ip = self._parse_ip_from_path(path)
        self._resource_monitor = PLCResourceMonitor(
            plc_ip=ip,
            max_rps=max_rps,
            min_request_interval_ms=min_request_interval * 1000,
        )

        self._last_request_time = 0.0
        self._lock = asyncio.Lock()

        logger.info(
            "AsyncLogixDriver initialized: max_concurrent=%s, "
            "min_interval=%.1fms, max_rps=%s",
            max_concurrent_requests,
            min_request_interval * 1000,
            max_rps,
        )

    async def open_async(self) -> None:
        """
        Open connection asynchronously.

        Creates the underlying EnhancedLogixDriver and opens the connection
        in the executor.

        Raises:
            CommError: If connection fails
        """
        if self._driver is not None:
            return

        def _open() -> None:
            driver = EnhancedLogixDriver(
                self.path,
                init_tags=self._init_tags,
                **self._driver_kwargs,
            )
            driver.open()
            self._driver = driver

        loop = asyncio.get_event_loop()
        await loop.run_in_executor(self._executor, _open)
        self._closed = False

    async def close_async(self) -> None:
        """Close connection asynchronously."""
        if self._driver is None:
            return

        def _close() -> None:
            if self._driver:
                try:
                    self._driver.close()
                except Exception as e:
                    logger.debug("Error closing driver: %s", e)
                finally:
                    self._driver = None

        loop = asyncio.get_event_loop()
        await loop.run_in_executor(self._executor, _close)
        self._closed = True

    async def _async_wait_for_rate_limit(self) -> None:
        """Non-blocking rate-limit wait for async callers.

        Instead of raising RateLimitError (which forces callers to catch
        and sleep themselves), this loops with ``asyncio.sleep`` until the
        resource monitor permits the next request — giving async consumers
        the same transparent throttling that sync consumers get via
        ``wait_for_rate_limit()``.
        """
        while True:
            try:
                self._resource_monitor.check_rate_limit()
                return
            except RateLimitError:
                await asyncio.sleep(0.01)

    async def read_async(self, *tags: str) -> Union[Tag, Sequence[Tag]]:
        """
        Read tag(s) with automatic throttling and fragmentation.

        Args:
            *tags: One or more tag names to read

        Returns:
            Single Tag if one tag, Sequence[Tag] if multiple

        Raises:
            CommError: If not connected or read fails
        """
        self._ensure_connected()

        async with self._semaphore:
            async with self._lock:
                elapsed = time.time() - self._last_request_time
                if elapsed < self.min_request_interval:
                    await asyncio.sleep(self.min_request_interval - elapsed)
                await self._async_wait_for_rate_limit()
                self._last_request_time = time.time()

            def _read() -> Union[Tag, Sequence[Tag]]:
                if self._driver is None:
                    raise CommError("Driver not connected")
                return self._driver.read(*tags)

            loop = asyncio.get_event_loop()
            try:
                result = await loop.run_in_executor(self._executor, _read)
                self._resource_monitor.record_success()
                return result
            except Exception as e:
                self._resource_monitor.record_error(e)
                raise

    async def write_async(self, *tags_values: Any) -> Union[Tag, Sequence[Tag]]:
        """
        Write tag(s) with automatic throttling.

        Args:
            *tags_values: Alternating tag names and values, e.g. ('Tag1', 42, 'Tag2', 0)

        Returns:
            Single Tag or Sequence[Tag] with write results

        Raises:
            CommError: If not connected or write fails
        """
        self._ensure_connected()

        async with self._semaphore:
            async with self._lock:
                elapsed = time.time() - self._last_request_time
                if elapsed < self.min_request_interval:
                    await asyncio.sleep(self.min_request_interval - elapsed)
                await self._async_wait_for_rate_limit()
                self._last_request_time = time.time()

            def _write() -> Union[Tag, Sequence[Tag]]:
                if self._driver is None:
                    raise CommError("Driver not connected")
                return self._driver.write(*tags_values)

            loop = asyncio.get_event_loop()
            try:
                result = await loop.run_in_executor(self._executor, _write)
                self._resource_monitor.record_success()
                return result
            except Exception as e:
                self._resource_monitor.record_error(e)
                raise

    async def read_many_async(self, tags: List[str]) -> List[Union[Tag, Sequence[Tag]]]:
        """
        Read many tags with controlled concurrency.

        Batches requests to respect rate limits and semaphore.

        Args:
            tags: List of tag names to read

        Returns:
            List of read results (one per tag)
        """
        results: List[Union[Tag, Sequence[Tag]]] = []
        for i in range(0, len(tags), self.max_concurrent_requests):
            batch = tags[i : i + self.max_concurrent_requests]
            batch_results = await asyncio.gather(
                *[self.read_async(tag) for tag in batch]
            )
            results.extend(batch_results)
        return results

    def get_fragmentation_stats(self) -> FragmentationStats:
        """
        Get fragmentation stats from last read (if any).

        Returns:
            FragmentationStats from underlying driver, or empty stats
        """
        if self._driver is None:
            return FragmentationStats()
        return self._driver.last_fragmentation_stats

    def _ensure_connected(self) -> None:
        """Raise if not connected."""
        if self._driver is None or self._closed:
            raise CommError(
                "Driver not connected. Call open_async() or use async with."
            )

    def _parse_ip_from_path(self, path: str) -> str:
        """Extract IP from path."""
        return path.split("/")[0]

    async def __aenter__(self) -> "AsyncLogixDriver":
        await self.open_async()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> bool:
        await self.close_async()
        return False

    def __del__(self) -> None:
        """Shutdown executor on deletion."""
        try:
            self._executor.shutdown(wait=False)
        except Exception:
            pass
