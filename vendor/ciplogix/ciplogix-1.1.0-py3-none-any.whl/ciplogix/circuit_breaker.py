"""
Circuit Breaker Pattern Implementation

Prevents cascade failures by detecting repeated failures and opening
the circuit to give PLCs time to recover.

Based on Martin Fowler's Circuit Breaker pattern.
"""

import time
import logging
import threading
from enum import Enum
from typing import Callable, Optional, Any

from .exceptions import CircuitBreakerError

logger = logging.getLogger(__name__)


class CircuitState(Enum):
    """Circuit breaker states."""
    CLOSED = "CLOSED"      # Normal operation
    OPEN = "OPEN"          # Failures detected, blocking requests
    HALF_OPEN = "HALF_OPEN"  # Testing if service recovered


class CircuitBreaker:
    """
    Circuit Breaker for PLC communication.
    
    Prevents overwhelming a failing PLC by:
    - Tracking failure rate
    - Opening circuit after threshold failures
    - Automatically attempting recovery
    - Closing circuit when PLC recovers
    
    Usage:
        breaker = CircuitBreaker(failure_threshold=5, timeout=60)
        
        try:
            result = breaker.call(plc.read, 'MyTag')
        except CircuitBreakerError:
            print("Circuit OPEN - PLC unavailable")
    """
    
    def __init__(self,
                 failure_threshold: int = 5,
                 timeout: int = 60,
                 expected_exception: type = Exception):
        """
        Initialize circuit breaker.
        
        Args:
            failure_threshold: Number of failures before opening (default: 5)
            timeout: Seconds to wait before retry (default: 60)
            expected_exception: Exception type that triggers circuit
        """
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.expected_exception = expected_exception
        
        # State tracking
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.last_failure_time: Optional[float] = None
        self.last_success_time: Optional[float] = None
        
        # Statistics
        self.stats = {
            'total_calls': 0,
            'total_failures': 0,
            'total_successes': 0,
            'times_opened': 0,
            'times_closed': 0,
            'current_state': 'CLOSED',
        }
        
        # Thread safety
        self._lock = threading.Lock()
        
        logger.info(
            f"CircuitBreaker initialized: threshold={failure_threshold}, "
            f"timeout={timeout}s"
        )
    
    def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Call function with circuit breaker protection.
        
        Args:
            func: Function to call
            *args: Positional arguments for function
            **kwargs: Keyword arguments for function
            
        Returns:
            Function result
            
        Raises:
            CircuitBreakerError: If circuit is OPEN
            Exception: If function raises exception
        """
        with self._lock:
            self.stats['total_calls'] += 1
            
            if self.state == CircuitState.OPEN:
                if self._should_attempt_reset():
                    self.state = CircuitState.HALF_OPEN
                    logger.info("Circuit breaker entering HALF_OPEN state")
                else:
                    remaining = self.timeout - (time.time() - self.last_failure_time)
                    raise CircuitBreakerError(
                        f"Circuit breaker is OPEN. "
                        f"Retry in {remaining:.0f}s. "
                        f"Failures: {self.failure_count}/{self.failure_threshold}"
                    )
        
        # Execute function (outside lock to allow concurrency)
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        
        except self.expected_exception as e:
            self._on_failure()
            raise
    
    def _should_attempt_reset(self) -> bool:
        """Check if enough time has passed to attempt reset."""
        if self.last_failure_time is None:
            return True
        return time.time() - self.last_failure_time >= self.timeout
    
    def _on_success(self) -> None:
        """Handle successful call."""
        with self._lock:
            self.stats['total_successes'] += 1
            self.last_success_time = time.time()
            
            if self.state == CircuitState.HALF_OPEN:
                # Success in HALF_OPEN → close circuit
                self._close_circuit()
            elif self.state == CircuitState.CLOSED:
                # Success in CLOSED → reset failure count
                self.failure_count = 0
    
    def _on_failure(self) -> None:
        """Handle failed call."""
        with self._lock:
            self.stats['total_failures'] += 1
            self.failure_count += 1
            self.last_failure_time = time.time()
            
            if self.failure_count >= self.failure_threshold:
                self._open_circuit()
    
    def _open_circuit(self) -> None:
        """Open the circuit."""
        if self.state != CircuitState.OPEN:
            self.state = CircuitState.OPEN
            self.stats['times_opened'] += 1
            self.stats['current_state'] = 'OPEN'
            
            logger.error(
                f"🚨 Circuit breaker OPENED! "
                f"Failures: {self.failure_count}/{self.failure_threshold}. "
                f"Will retry in {self.timeout}s"
            )
    
    def _close_circuit(self) -> None:
        """Close the circuit (recovered)."""
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.stats['times_closed'] += 1
        self.stats['current_state'] = 'CLOSED'
        
        logger.info(
            f"✅ Circuit breaker CLOSED - PLC recovered. "
            f"Total successes: {self.stats['total_successes']}"
        )
    
    def reset(self) -> None:
        """Manually reset circuit breaker."""
        with self._lock:
            self.state = CircuitState.CLOSED
            self.failure_count = 0
            self.last_failure_time = None
            logger.info("Circuit breaker manually reset")
    
    def get_state(self) -> CircuitState:
        """Get current circuit state."""
        return self.state
    
    def get_stats(self) -> dict:
        """Get circuit breaker statistics."""
        with self._lock:
            return {
                **self.stats,
                'failure_count': self.failure_count,
                'failure_threshold': self.failure_threshold,
                'timeout': self.timeout,
                'last_failure_time': self.last_failure_time,
                'last_success_time': self.last_success_time,
            }

