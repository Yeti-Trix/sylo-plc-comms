"""
Optimized Socket Utilities for PLC Communication

Provides:
- OptimizedSocket: standalone TCP socket with dynamic buffers and TCP tuning
- apply_socket_optimizations(): apply TCP tuning to any existing socket

EnhancedLogixDriver uses apply_socket_optimizations() to tune pycomm3's
socket after connection.
"""

import socket
import struct
import logging
from typing import Optional

from .exceptions import CommError

logger = logging.getLogger(__name__)

HEADER_SIZE = 24  # EtherNet/IP header size
DEFAULT_BUFFER_SIZE = 4096
MIN_BUFFER_SIZE = 1024
MAX_BUFFER_SIZE = 65536


def apply_socket_optimizations(sock: socket.socket) -> None:
    """
    Apply TCP optimizations to an existing socket.

    Safe to call on any connected TCP socket.  Failures on individual
    options are logged but do not raise.

    Optimizations applied:
    - TCP_NODELAY (disable Nagle for low latency)
    - 256 KB send/receive buffers
    - TCP keepalive (60 s idle, 10 s interval, 6 probes where supported)
    """
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    except OSError as e:
        logger.debug("TCP_NODELAY not applied: %s", e)

    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 262144)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 262144)
    except OSError as e:
        logger.debug("Buffer resize not applied: %s", e)

    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        if hasattr(socket, "TCP_KEEPIDLE"):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 60)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 10)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 6)
    except OSError as e:
        logger.debug("Keepalive not applied: %s", e)


class OptimizedSocket:
    """
    Standalone optimized TCP socket for PLC communication.

    Features over a plain socket:
    - Dynamic buffer sizing based on EtherNet/IP header length field
    - TCP_NODELAY, large buffers, keepalive (via apply_socket_optimizations)
    - Exact-byte receive with partial-read handling
    """

    def __init__(self, timeout: float = 5.0):
        self.sock: Optional[socket.socket] = None
        self.timeout = timeout
        self._connected = False

    def connect(self, host: str, port: int) -> None:
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(self.timeout)
            apply_socket_optimizations(self.sock)
            self.sock.connect((socket.gethostbyname(host), port))
            self._connected = True
            logger.info("Connected to %s:%s", host, port)
        except socket.error as e:
            self._connected = False
            raise CommError(f"Failed to connect to {host}:{port}: {e}") from e

    def send(self, data: bytes, timeout: Optional[float] = None) -> int:
        if timeout is not None:
            old_timeout = self.sock.gettimeout()
            self.sock.settimeout(timeout)
        try:
            total_sent = 0
            while total_sent < len(data):
                try:
                    sent = self.sock.send(data[total_sent:])
                    if sent == 0:
                        raise CommError("Socket connection broken (sent 0 bytes)")
                    total_sent += sent
                except socket.error as e:
                    raise CommError(f"Socket send error: {e}") from e
            return total_sent
        finally:
            if timeout is not None:
                self.sock.settimeout(old_timeout)

    def receive(self, timeout: Optional[float] = None) -> bytes:
        if timeout is not None:
            old_timeout = self.sock.gettimeout()
            self.sock.settimeout(timeout)
        try:
            header = self._recv_exact(HEADER_SIZE, DEFAULT_BUFFER_SIZE)
            data_len = struct.unpack_from("<H", header, 2)[0]
            buffer_size = min(max(data_len, MIN_BUFFER_SIZE), MAX_BUFFER_SIZE)
            if data_len > 0:
                data = self._recv_exact(data_len, buffer_size)
                return header + data
            return header
        except socket.error as e:
            raise CommError(f"Socket receive error: {e}") from e
        finally:
            if timeout is not None:
                self.sock.settimeout(old_timeout)

    def _recv_exact(self, size: int, buffer_size: int = DEFAULT_BUFFER_SIZE) -> bytes:
        chunks = []
        remaining = size
        while remaining > 0:
            try:
                chunk = self.sock.recv(min(remaining, buffer_size))
                if not chunk:
                    raise CommError(
                        f"Socket closed unexpectedly. "
                        f"Expected {size} bytes, received {size - remaining}"
                    )
                chunks.append(chunk)
                remaining -= len(chunk)
            except socket.error as e:
                raise CommError(
                    f"Socket receive error after {size - remaining}/{size} bytes: {e}"
                ) from e
        return b"".join(chunks)

    def close(self) -> None:
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
            finally:
                self.sock = None
                self._connected = False

    @property
    def connected(self) -> bool:
        return self._connected and self.sock is not None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
