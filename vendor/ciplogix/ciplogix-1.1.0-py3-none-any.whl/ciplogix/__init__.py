"""
CIPLogix - Enhanced Allen-Bradley PLC Communication Library

An industrial-grade Python library for PLC communication with built-in
resource protection and performance optimization.

Based on pycomm3 but enhanced with:
- Automatic fragmentation for large arrays (>500 bytes)
- PLC resource protection (rate limiting, throttling)
- Optimized socket I/O (TCP_NODELAY, dynamic buffers, keepalive)
- Connection pooling with health monitoring
- Async driver (asyncio wrapper with non-blocking throttling)
- Circuit breaker (optional, integrated into driver)
- Resilient driver with configurable retry + exponential backoff
- CIP-compliant error handling
"""

try:
    from importlib.metadata import version as _get_version
    __version__ = _get_version("ciplogix")
except Exception:
    __version__ = "0.0.0"
__author__ = "Enhanced by Spencer Current, Based on pycomm3 by Ian Ottoway"
__license__ = "MIT"

# Core drivers
from .enhanced_logix_driver import EnhancedLogixDriver, FragmentationStats
from .resilient_logix_driver import (
    ResilientLogixDriver,
    LogixDriver,
    ReconnectionConfig,
    ConnectionLostError,
)
from .async_logix_driver import AsyncLogixDriver
from .connection_pool import ConnectionPool

# Socket optimisation utilities
from .socket_ import OptimizedSocket, apply_socket_optimizations

# Circuit breaker
from .circuit_breaker import CircuitBreaker, CircuitState

# Fragmentation
from .fragmentation import (
    FragmentationConfig,
    FragmentPlan,
    needs_fragmentation,
)

# Resource protection
from .resource_monitor import PLCResourceMonitor, SAFE_RATE_LIMITS

# Exceptions
from .exceptions import (
    BufferSaturationError,
    CircuitBreakerError,
    CommError,
    ConnectionPoolExhaustedError,
    FragmentationRequiredError,
    RateLimitError,
    RequestError,
    ResponseError,
    TagNotFoundError,
)

# Tags
from .tag import Tag

__all__ = [
    # Main drivers
    "LogixDriver",
    "ResilientLogixDriver",
    "EnhancedLogixDriver",
    "AsyncLogixDriver",

    # Connection management
    "ConnectionPool",
    "ReconnectionConfig",

    # Socket
    "OptimizedSocket",
    "apply_socket_optimizations",

    # Fault tolerance
    "CircuitBreaker",
    "CircuitState",

    # Fragmentation
    "FragmentationConfig",
    "FragmentationStats",
    "FragmentPlan",
    "needs_fragmentation",

    # Resource protection
    "PLCResourceMonitor",
    "SAFE_RATE_LIMITS",

    # Exceptions
    "BufferSaturationError",
    "CircuitBreakerError",
    "CommError",
    "ConnectionLostError",
    "ConnectionPoolExhaustedError",
    "FragmentationRequiredError",
    "RateLimitError",
    "RequestError",
    "ResponseError",
    "TagNotFoundError",

    # Data types
    "Tag",
]

