"""
Lazy Tag Loading System for CIPLogix  [EXPERIMENTAL]

WARNING: The CIP service methods (_send_get_attribute_request and
_send_get_instance_list_request) are NOT implemented.  LazyTagLoader
will always fall through to its fallback path or raise
NotImplementedError.  Do NOT rely on this module in production until
the CIP service integration is complete.

Design goals (once implemented):
1. On-demand tag discovery (only fetch when needed)
2. Per-connection tag cache with LRU eviction
3. Intelligent cache invalidation
4. Fallback to full discovery if needed
"""

import logging
import time
from typing import Dict, Optional, Any, List
from dataclasses import dataclass, field
from collections import OrderedDict
from threading import RLock

logger = logging.getLogger(__name__)


@dataclass
class TagInfo:
    """Cached information about a tag"""
    name: str
    tag_type: str
    dimensions: List[int] = field(default_factory=list)
    is_struct: bool = False
    is_array: bool = False
    element_size: int = 0  # Size of one element in bytes
    total_size: int = 0    # Total tag size in bytes
    member_info: Dict[str, Any] = field(default_factory=dict)  # For struct members
    
    # Cache metadata
    cached_at: float = field(default_factory=time.time)
    access_count: int = 0
    last_accessed: float = field(default_factory=time.time)
    
    def mark_accessed(self):
        """Update access statistics"""
        self.access_count += 1
        self.last_accessed = time.time()
    
    def is_stale(self, max_age_seconds: float = 300) -> bool:
        """Check if cache entry is stale (older than 5 minutes)"""
        return (time.time() - self.cached_at) > max_age_seconds
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            'name': self.name,
            'tag_type': self.tag_type,
            'dimensions': self.dimensions,
            'is_struct': self.is_struct,
            'is_array': self.is_array,
            'element_size': self.element_size,
            'total_size': self.total_size,
            'member_info': self.member_info,
        }


class LRUTagCache:
    """
    Least Recently Used cache for tag information.
    
    Automatically evicts least-used tags when cache is full.
    """
    
    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self.cache: OrderedDict[str, TagInfo] = OrderedDict()
        self.lock = RLock()  # Thread-safe
        
        # Statistics
        self.hits = 0
        self.misses = 0
        self.evictions = 0
    
    def get(self, tag_name: str) -> Optional[TagInfo]:
        """Get tag info from cache"""
        with self.lock:
            if tag_name in self.cache:
                # Move to end (most recently used)
                self.cache.move_to_end(tag_name)
                tag_info = self.cache[tag_name]
                tag_info.mark_accessed()
                self.hits += 1
                return tag_info
            else:
                self.misses += 1
                return None
    
    def put(self, tag_name: str, tag_info: TagInfo):
        """Add tag info to cache"""
        with self.lock:
            if tag_name in self.cache:
                # Update existing entry
                self.cache.move_to_end(tag_name)
            else:
                # Check if cache is full
                if len(self.cache) >= self.max_size:
                    # Evict least recently used
                    evicted_key, evicted_value = self.cache.popitem(last=False)
                    self.evictions += 1
                    logger.debug(
                        f"Cache full, evicted tag '{evicted_key}' "
                        f"(accessed {evicted_value.access_count} times)"
                    )
            
            self.cache[tag_name] = tag_info
    
    def invalidate(self, tag_name: Optional[str] = None):
        """Invalidate cache entry or entire cache"""
        with self.lock:
            if tag_name:
                if tag_name in self.cache:
                    del self.cache[tag_name]
                    logger.debug(f"Invalidated cache for tag '{tag_name}'")
            else:
                self.cache.clear()
                logger.debug("Invalidated entire tag cache")
    
    def clear(self):
        """Clear entire cache"""
        with self.lock:
            self.cache.clear()
            self.hits = 0
            self.misses = 0
            self.evictions = 0
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        with self.lock:
            total_requests = self.hits + self.misses
            hit_rate = (self.hits / total_requests * 100) if total_requests > 0 else 0
            
            return {
                'size': len(self.cache),
                'max_size': self.max_size,
                'hits': self.hits,
                'misses': self.misses,
                'hit_rate_percent': hit_rate,
                'evictions': self.evictions,
            }
    
    def __len__(self) -> int:
        with self.lock:
            return len(self.cache)
    
    def __contains__(self, tag_name: str) -> bool:
        with self.lock:
            return tag_name in self.cache


class LazyTagLoader:
    """
    Lazy tag loading system for CIPLogix.
    
    Instead of downloading the entire tag table at connection (164ms),
    only fetches tag information when first accessed (<1ms per tag).
    
    Target: Reduce connection time from 164ms to <50ms.
    """
    
    def __init__(
        self,
        connection: Any,  # The PLC connection object
        cache_size: int = 1000,
        enable_cache: bool = True,
        fallback_to_full: bool = True
    ):
        self.connection = connection
        self.cache = LRUTagCache(max_size=cache_size) if enable_cache else None
        self.fallback_to_full = fallback_to_full
        
        # Track if we've done full discovery
        self.full_discovery_done = False
        self.full_tag_list: Dict[str, TagInfo] = {}
        
        # Statistics
        self.lazy_fetches = 0
        self.full_fetches = 0
        self.cache_saves = 0  # How many full fetches avoided by cache
        
        logger.debug("LazyTagLoader initialized (cache enabled, full discovery deferred)")
    
    def get_tag_info(self, tag_name: str, force_refresh: bool = False) -> Optional[TagInfo]:
        """
        Get tag information, fetching lazily if needed.
        
        Args:
            tag_name: Name of the tag to lookup
            force_refresh: If True, bypass cache and fetch fresh data
        
        Returns:
            TagInfo object, or None if tag doesn't exist
        """
        # Check cache first (unless force refresh)
        if not force_refresh and self.cache:
            cached = self.cache.get(tag_name)
            if cached and not cached.is_stale():
                logger.debug(f"Tag '{tag_name}' found in cache")
                self.cache_saves += 1
                return cached
        
        # Try lazy fetch (single tag)
        tag_info = self._fetch_single_tag(tag_name)
        
        if tag_info:
            # Cache the result
            if self.cache:
                self.cache.put(tag_name, tag_info)
            self.lazy_fetches += 1
            return tag_info
        
        # Fallback to full discovery if enabled and not already done
        if self.fallback_to_full and not self.full_discovery_done:
            logger.info(
                f"Tag '{tag_name}' not found via lazy fetch, "
                "attempting full tag discovery..."
            )
            if self._do_full_discovery():
                # Try again from full list
                return self.full_tag_list.get(tag_name)
        
        return None
    
    def _fetch_single_tag(self, tag_name: str) -> Optional[TagInfo]:
        """
        Fetch information for a single tag using CIP services.
        
        This is the fast path - only gets info for the requested tag.
        """
        try:
            # Use CIP service 0x03 (Get Attribute Single) for fast lookup
            # This avoids downloading the entire tag table
            
            # Parse tag name to handle arrays and members
            base_tag, *attributes = self._parse_tag_name(tag_name)
            
            # Send CIP request for this specific tag
            # (This would integrate with actual CIP driver code)
            tag_data = self._send_get_attribute_request(base_tag)
            
            if not tag_data:
                return None
            
            # Parse response into TagInfo
            tag_info = self._parse_tag_data(tag_name, tag_data)
            
            logger.debug(f"Lazy fetched tag '{tag_name}': {tag_info.tag_type}")
            return tag_info
            
        except Exception as e:
            logger.warning(f"Failed to lazy fetch tag '{tag_name}': {e}")
            return None
    
    def _do_full_discovery(self) -> bool:
        """
        Perform full tag table discovery (slow path).
        
        This is the fallback when lazy loading fails.
        Downloads entire tag list from PLC.
        """
        if self.full_discovery_done:
            return True
        
        try:
            logger.info("Starting full tag discovery...")
            start = time.time()
            
            # Use CIP service 0x55 (Get Instance Attribute List)
            # This gets all tags from the PLC
            tag_list_data = self._send_get_instance_list_request()
            
            if not tag_list_data:
                return False
            
            # Parse all tags
            for tag_data in tag_list_data:
                tag_info = self._parse_tag_data(tag_data['name'], tag_data)
                self.full_tag_list[tag_info.name] = tag_info
                
                # Also add to cache
                if self.cache:
                    self.cache.put(tag_info.name, tag_info)
            
            self.full_discovery_done = True
            self.full_fetches += 1
            
            elapsed = (time.time() - start) * 1000
            logger.info(
                f"Full tag discovery complete: {len(self.full_tag_list)} tags "
                f"in {elapsed:.1f}ms"
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Full tag discovery failed: {e}")
            return False
    
    def _parse_tag_name(self, tag_name: str) -> List[str]:
        """
        Parse tag name into components.
        
        Examples:
            "MyTag" -> ["MyTag"]
            "MyTag.Member" -> ["MyTag", "Member"]
            "MyArray[5]" -> ["MyArray", "[5]"]
            "MyStruct.Array[5].Member" -> ["MyStruct", "Array[5]", "Member"]
        """
        # Simple parsing - split on '.' but keep array indices
        parts = []
        current = ""
        in_brackets = False
        
        for char in tag_name:
            if char == '[':
                in_brackets = True
                current += char
            elif char == ']':
                in_brackets = False
                current += char
            elif char == '.' and not in_brackets:
                if current:
                    parts.append(current)
                current = ""
            else:
                current += char
        
        if current:
            parts.append(current)
        
        return parts
    
    def _send_get_attribute_request(self, tag_name: str) -> Optional[Dict[str, Any]]:
        """
        Send CIP service 0x03 (Get Attribute Single) for a specific tag.

        NOT IMPLEMENTED — requires deep pycomm3 CIP stack integration.
        Returns None so callers fall through to the full-discovery path.
        """
        raise NotImplementedError(
            "_send_get_attribute_request requires CIP service 0x03 integration "
            "which is not yet implemented.  Use pycomm3's built-in tag list instead."
        )

    def _send_get_instance_list_request(self) -> Optional[List[Dict[str, Any]]]:
        """
        Send CIP service 0x55 (Get Instance Attribute List) for all tags.

        NOT IMPLEMENTED — requires deep pycomm3 CIP stack integration.
        """
        raise NotImplementedError(
            "_send_get_instance_list_request requires CIP service 0x55 integration "
            "which is not yet implemented.  Use pycomm3's built-in tag list instead."
        )

    def _parse_tag_data(self, tag_name: str, tag_data: Dict[str, Any]) -> TagInfo:
        """Parse CIP response data into a TagInfo — placeholder until CIP integration."""
        return TagInfo(
            name=tag_name,
            tag_type=tag_data.get('tag_type', 'DINT'),
            element_size=tag_data.get('element_size', 4),
            total_size=tag_data.get('total_size', 4),
        )
    
    def get_all_tags(self) -> Dict[str, TagInfo]:
        """
        Get all available tags.
        
        Triggers full discovery if not already done.
        """
        if not self.full_discovery_done:
            self._do_full_discovery()
        
        return self.full_tag_list.copy()
    
    def prefetch_tags(self, tag_names: List[str]):
        """
        Prefetch multiple tags to warm up the cache.
        
        Useful if you know which tags you'll need.
        """
        logger.debug(f"Prefetching {len(tag_names)} tags...")
        for tag_name in tag_names:
            self.get_tag_info(tag_name)
    
    def invalidate_cache(self, tag_name: Optional[str] = None):
        """Invalidate cache for specific tag or entire cache"""
        if self.cache:
            self.cache.invalidate(tag_name)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get loader statistics"""
        stats = {
            'lazy_fetches': self.lazy_fetches,
            'full_fetches': self.full_fetches,
            'cache_saves': self.cache_saves,
            'full_discovery_done': self.full_discovery_done,
            'known_tags': len(self.full_tag_list),
        }
        
        if self.cache:
            stats['cache'] = self.cache.get_stats()
        
        return stats
    
    def __repr__(self) -> str:
        stats = self.get_statistics()
        return (
            f"LazyTagLoader("
            f"lazy_fetches={stats['lazy_fetches']}, "
            f"cache_hit_rate={stats.get('cache', {}).get('hit_rate_percent', 0):.1f}%"
            f")"
        )


class ConnectionWithLazyLoading:
    """
    Wrapper for PLC connection that adds lazy tag loading.
    
    Usage:
        conn = ConnectionWithLazyLoading(plc_ip='10.1.200.5', init_tags=False)
        conn.connect()  # Fast! <50ms
        
        # Tags loaded on-demand
        conn.read('MyTag')  # Fetches tag info if needed
    """
    
    def __init__(self, plc_ip: str, init_tags: bool = False, **kwargs):
        self.plc_ip = plc_ip
        self.init_tags = init_tags
        self.connection = None
        self.lazy_loader: Optional[LazyTagLoader] = None
        
    def connect(self):
        """Connect to PLC with fast initialization"""
        start = time.time()
        
        # Create connection (without tag initialization)
        # TODO: Integrate with actual connection class
        # self.connection = ActualConnection(self.plc_ip, init_tags=False)
        
        # Create lazy loader
        self.lazy_loader = LazyTagLoader(
            connection=self.connection,
            enable_cache=True,
            fallback_to_full=self.init_tags  # Only fallback if user wants full init
        )
        
        # If init_tags=True, do full discovery now
        if self.init_tags:
            self.lazy_loader._do_full_discovery()
        
        elapsed = (time.time() - start) * 1000
        logger.info(f"Connection established in {elapsed:.1f}ms (lazy={not self.init_tags})")
    
    def get_tag_info(self, tag_name: str) -> Optional[TagInfo]:
        """Get tag information (uses lazy loading)"""
        if not self.lazy_loader:
            raise RuntimeError("Not connected")
        return self.lazy_loader.get_tag_info(tag_name)
    
    def read(self, tag_name: str):
        """Read tag value (fetches tag info if needed)"""
        # Get tag info (may trigger lazy fetch)
        tag_info = self.get_tag_info(tag_name)
        if not tag_info:
            raise ValueError(f"Tag '{tag_name}' not found")
        
        # Proceed with actual read
        # TODO: Integrate with actual read logic
        pass
    
    def get_stats(self) -> Dict[str, Any]:
        """Get lazy loading statistics"""
        if self.lazy_loader:
            return self.lazy_loader.get_statistics()
        return {}


