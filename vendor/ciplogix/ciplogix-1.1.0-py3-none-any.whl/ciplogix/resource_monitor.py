"""
PLC Resource Protection Module

Implements rate limiting, throttling, and buffer saturation detection
to prevent overwhelming PLC communication resources.

Critical for production stability - MUST be used with async operations.
"""

import time
import logging
import threading
from collections import deque
from typing import Dict, Optional

logger = logging.getLogger(__name__)

# Industry-tested safe limits per PLC model
SAFE_RATE_LIMITS = {
    'L71':   {'max_rps': 30, 'max_concurrent': 2, 'buffer_kb': 192},
    'L81E':  {'max_rps': 75, 'max_concurrent': 3, 'buffer_kb': 384},
    'L83E':  {'max_rps': 100, 'max_concurrent': 5, 'buffer_kb': 512},
    'default': {'max_rps': 50, 'max_concurrent': 3, 'buffer_kb': 128},
}


class PLCResourceMonitor:
    """
    Monitors and enforces safe PLC communication patterns.
    
    Prevents buffer saturation by:
    - Tracking requests per second
    - Detecting error patterns
    - Automatic throttling on failures
    - Adaptive backoff
    
    Usage:
        monitor = PLCResourceMonitor('192.168.1.10')
        monitor.check_rate_limit()  # Raises RateLimitError if too fast
        monitor.record_success()     # Track successful operation
        monitor.record_error(error)  # Track failures and throttle
    """
    
    def __init__(self, 
                 plc_ip: str,
                 max_rps: int = 50,
                 burst_requests: int = 10,
                 min_request_interval_ms: float = 10,
                 max_concurrent: int = 3):
        """
        Initialize resource monitor.
        
        Args:
            plc_ip: PLC IP address for logging
            max_rps: Maximum sustained requests per second
            burst_requests: Maximum simultaneous requests
            min_request_interval_ms: Minimum milliseconds between requests
            max_concurrent: Maximum concurrent connections to this PLC
        """
        self.plc_ip = plc_ip
        self.max_rps = max_rps
        self.burst_requests = burst_requests
        self.min_request_interval = min_request_interval_ms / 1000.0
        self.max_concurrent = max_concurrent
        
        # Rolling window for rate tracking
        self.request_times = deque(maxlen=100)
        
        # Error tracking
        self.error_count = 0
        self.consecutive_errors = 0
        self.last_error_time = 0
        
        # Throttling state
        self.throttle_until = 0
        self.throttle_duration = 0
        
        # Last request tracking
        self.last_request_time = 0
        
        # Thread safety
        self._lock = threading.Lock()
        
        # Statistics
        self.total_requests = 0
        self.total_errors = 0
        self.total_throttled = 0
    
    def wait_for_rate_limit(self) -> None:
        """
        Block until the next request is allowed, then return.

        Use this for transparent throttling: the caller is paused until
        the rate limit permits the request, then proceeds.
        """
        while True:
            wait_time = 0.0
            with self._lock:
                now = time.time()

                if now < self.throttle_until:
                    wait_time = self.throttle_until - now
                else:
                    time_since_last = now - self.last_request_time
                    if time_since_last < self.min_request_interval:
                        wait_time = self.min_request_interval - time_since_last
                    else:
                        self.request_times.append(now)
                        if len(self.request_times) >= self.burst_requests:
                            window_duration = now - self.request_times[0]
                            if window_duration >= 0.25:
                                current_rps = len(self.request_times) / window_duration
                                if current_rps > self.max_rps:
                                    self.total_throttled += 1
                                    wait_time = 1.0 / self.max_rps
                        if wait_time == 0:
                            self.last_request_time = now
                            self.total_requests += 1
                            return

            time.sleep(wait_time)

    def check_rate_limit(self) -> None:
        """
        Check if request would exceed safe rate limits.

        Raises:
            RateLimitError: If rate limit would be exceeded
        """
        from .exceptions import RateLimitError

        with self._lock:
            now = time.time()

            # Check if in throttle mode
            if now < self.throttle_until:
                self.total_throttled += 1
                remaining = self.throttle_until - now
                raise RateLimitError(
                    f"PLC {self.plc_ip} resource protection: throttled for {remaining:.1f}s. "
                    f"Reason: {self.consecutive_errors} consecutive errors detected. "
                    f"Total throttled: {self.total_throttled}"
                )

            # Check minimum interval since last request
            time_since_last = now - self.last_request_time
            if time_since_last < self.min_request_interval:
                wait_time = self.min_request_interval - time_since_last
                raise RateLimitError(
                    f"PLC {self.plc_ip}: minimum interval {self.min_request_interval*1000:.1f}ms not met. "
                    f"Wait {wait_time*1000:.1f}ms"
                )

            # Check requests per second (only after enough samples
            # over a meaningful window to avoid false positives)
            self.request_times.append(now)
            if len(self.request_times) >= self.burst_requests:
                window_duration = now - self.request_times[0]
                if window_duration >= 0.25:
                    current_rps = len(self.request_times) / window_duration
                    if current_rps > self.max_rps:
                        self.total_throttled += 1
                        delay = 1.0 / self.max_rps
                        raise RateLimitError(
                            f"PLC {self.plc_ip}: Rate limit exceeded: {current_rps:.1f} req/s "
                            f"(max: {self.max_rps}). Back off {delay*1000:.1f}ms. "
                            f"Total requests: {self.total_requests}"
                        )

            # Update last request time
            self.last_request_time = now
            self.total_requests += 1
    
    def record_error(self, error: Exception, error_type: Optional[str] = None) -> None:
        """
        Track error and trigger protective throttling if needed.
        
        Args:
            error: The exception that occurred
            error_type: Optional error type string for classification
        """
        with self._lock:
            self.error_count += 1
            self.total_errors += 1
            self.consecutive_errors += 1
            self.last_error_time = time.time()
            
            error_str = str(error).lower()
            error_type_str = (error_type or "").lower()
            
            # Detect buffer saturation errors (CRITICAL)
            buffer_errors = [
                'connection reset',
                'insufficient resources',
                'resource unavailable',
                'connection timeout',
                'forward open failed',
                'buffer',
                'overload',
            ]
            
            is_buffer_error = any(e in error_str or e in error_type_str for e in buffer_errors)
            
            if is_buffer_error:
                # Aggressive throttle on buffer errors
                self.throttle_duration = min(2 ** self.consecutive_errors, 60)
                self.throttle_until = time.time() + self.throttle_duration
                
                logger.error(
                    f"🚨 PLC BUFFER SATURATION DETECTED on {self.plc_ip}! "
                    f"Throttling for {self.throttle_duration}s. "
                    f"Error count: {self.consecutive_errors}. "
                    f"Error: {error}"
                )
            elif self.consecutive_errors >= 3:
                # Moderate throttle on repeated errors
                self.throttle_duration = min(self.consecutive_errors, 10)
                self.throttle_until = time.time() + self.throttle_duration
                
                logger.warning(
                    f"Multiple consecutive errors ({self.consecutive_errors}) on {self.plc_ip}. "
                    f"Throttling for {self.throttle_duration}s. "
                    f"Error: {error}"
                )
            else:
                logger.debug(f"Error recorded for {self.plc_ip}: {error}")
    
    def record_success(self) -> None:
        """
        Record successful operation.
        
        Gradually reduces error count to allow recovery from throttling.
        """
        with self._lock:
            # Decay error count on success (gradual recovery)
            if self.consecutive_errors > 0:
                self.consecutive_errors = max(0, self.consecutive_errors - 1)
                
            # Reset error count if no errors for a while
            if time.time() - self.last_error_time > 60:
                self.error_count = 0
                self.consecutive_errors = 0
    
    def get_stats(self) -> Dict[str, any]:
        """
        Get monitoring statistics.
        
        Returns:
            Dict with monitoring metrics
        """
        with self._lock:
            now = time.time()
            window_duration = now - self.request_times[0] if self.request_times else 0
            current_rps = len(self.request_times) / window_duration if window_duration > 0 else 0
            
            return {
                'plc_ip': self.plc_ip,
                'total_requests': self.total_requests,
                'total_errors': self.total_errors,
                'total_throttled': self.total_throttled,
                'error_rate': self.total_errors / self.total_requests if self.total_requests > 0 else 0,
                'current_rps': current_rps,
                'max_rps': self.max_rps,
                'consecutive_errors': self.consecutive_errors,
                'is_throttled': time.time() < self.throttle_until,
                'throttle_remaining': max(0, self.throttle_until - time.time()),
            }
    
    def reset(self) -> None:
        """Reset all counters and throttling."""
        with self._lock:
            self.request_times.clear()
            self.error_count = 0
            self.consecutive_errors = 0
            self.throttle_until = 0
            self.throttle_duration = 0
            self.last_error_time = 0
            self.last_request_time = 0
            logger.info(f"Resource monitor reset for {self.plc_ip}")

