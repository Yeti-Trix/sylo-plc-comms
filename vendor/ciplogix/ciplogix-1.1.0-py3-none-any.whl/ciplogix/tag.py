"""
Tag Data Class

Represents a PLC tag with value, type, and error information.
"""

from typing import Any, Optional


class Tag:
    """
    Represents a single PLC tag read/write result.
    
    Attributes:
        tag: Tag name
        value: Tag value (None if error)
        type: Data type string
        error: Error message (None if successful)
    """
    
    def __init__(self, 
                 tag: str,
                 value: Any = None,
                 tag_type: Optional[str] = None,
                 error: Optional[str] = None,
                 type: Optional[str] = None):  # Support pycomm3 compatibility
        """
        Initialize Tag.
        
        Args:
            tag: Tag name
            value: Tag value
            tag_type: Data type (DINT, REAL, etc.)
            error: Error message if operation failed
            type: Alias for tag_type (pycomm3 compatibility)
        """
        self.tag = tag
        self.value = value
        # Support both 'type' and 'tag_type' parameters
        self.type = type if type is not None else tag_type
        self.error = error
    
    def __bool__(self) -> bool:
        """Tag is True if no error occurred."""
        return self.error is None
    
    def __repr__(self) -> str:
        if self.error:
            return f"Tag('{self.tag}', error='{self.error}')"
        return f"Tag('{self.tag}', value={self.value!r}, type='{self.type}')"
    
    def __str__(self) -> str:
        if self.error:
            return f"❌ {self.tag}: {self.error}"
        return f"✓ {self.tag} = {self.value} ({self.type})"

