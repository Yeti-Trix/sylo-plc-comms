"""
Connection Pool Implementation

Manages reusable PLC connections with:
- Per-PLC connection limits
- Global connection limit across all PLCs
- Lightweight health checks
- Automatic cleanup of stale connections
- Thread-safe operation
"""

import threading
import time
import logging
from typing import Dict, List, Optional, Tuple
from contextlib import contextmanager

from .exceptions import CommError, ConnectionPoolExhaustedError

logger = logging.getLogger(__name__)


class ConnectionPool:
    """
    Connection pool for reusing PLC connections.
    
    Critical safety features:
    - Per-PLC limits prevent exhausting single PLC resources
    - Global limit prevents system-wide resource exhaustion
    - Health checks avoid returning dead connections
    - Automatic cleanup of idle connections
    
    Usage:
        pool = ConnectionPool(max_size=2, max_global_connections=8)
        
        # Option 1: Context manager
        with pool.acquire('192.168.1.10') as plc:
            value = plc.read('MyTag')
        
        # Option 2: Manual acquire/release
        plc = pool.acquire('192.168.1.10')
        try:
            value = plc.read('MyTag')
        finally:
            pool.release(plc, '192.168.1.10')
    """
    
    def __init__(self,
                 max_size: int = 2,
                 max_global_connections: int = 8,
                 idle_timeout: int = 300,
                 health_check_interval: int = 60):
        """
        Initialize connection pool.
        
        Args:
            max_size: Maximum connections per PLC (default: 2)
            max_global_connections: Maximum total connections (default: 8)
            idle_timeout: Seconds before idle connection is closed (default: 300)
            health_check_interval: Seconds between health checks (default: 60)
        """
        self.max_size = max_size
        self.max_global_connections = max_global_connections
        self.idle_timeout = idle_timeout
        self.health_check_interval = health_check_interval
        
        # Connection storage: {(ip, slot): [(connection, last_used_time), ...]}
        self._pool: Dict[Tuple[str, Optional[int]], List[Tuple[any, float]]] = {}
        
        # Active connection tracking
        self._active_connections = 0
        self._connection_count_by_plc: Dict[Tuple[str, Optional[int]], int] = {}
        
        # Thread safety
        self._lock = threading.Lock()
        
        # Background cleanup thread
        self._cleanup_thread: Optional[threading.Thread] = None
        self._stop_cleanup = threading.Event()
        
        # Statistics
        self.stats = {
            'total_acquired': 0,
            'total_released': 0,
            'total_created': 0,
            'total_reused': 0,
            'total_closed': 0,
            'health_check_failures': 0,
        }
        
        # Start background cleanup
        self._start_cleanup_thread()
        
        logger.info(
            f"ConnectionPool initialized: max_size={max_size}, "
            f"max_global={max_global_connections}, idle_timeout={idle_timeout}s"
        )
    
    def acquire(self, path: str) -> any:
        """
        Acquire a connection from the pool.
        
        Args:
            path: PLC path (e.g., '192.168.1.10' or '192.168.1.10/1')
            
        Returns:
            LogixDriver instance
            
        Raises:
            ConnectionPoolExhaustedError: If limits exceeded
            CommError: If connection creation fails
        """
        with self._lock:
            # Check global limit
            if self._active_connections >= self.max_global_connections:
                raise ConnectionPoolExhaustedError(
                    f"Global connection limit reached ({self.max_global_connections}). "
                    f"Active: {self._active_connections}. "
                    "Release connections before acquiring new ones."
                )
            
            # Parse path
            key = self._parse_path(path)
            
            # Try to reuse existing connection
            if key in self._pool and self._pool[key]:
                while self._pool[key]:
                    conn, _ = self._pool[key].pop(0)
                    
                    # Health check
                    if self._is_healthy(conn):
                        self._active_connections += 1
                        self._connection_count_by_plc[key] = \
                            self._connection_count_by_plc.get(key, 0) + 1
                        
                        self.stats['total_acquired'] += 1
                        self.stats['total_reused'] += 1
                        
                        logger.debug(f"Reused connection to {path}")
                        return conn
                    else:
                        # Connection unhealthy - close it
                        self._close_connection(conn)
                        self.stats['health_check_failures'] += 1
            
            # No healthy connection available - create new one
            conn = self._create_connection(path)
            
            self._active_connections += 1
            self._connection_count_by_plc[key] = \
                self._connection_count_by_plc.get(key, 0) + 1
            
            self.stats['total_acquired'] += 1
            self.stats['total_created'] += 1
            
            logger.info(
                f"Created new connection to {path}. "
                f"Active: {self._active_connections}/{self.max_global_connections}"
            )
            
            return conn
    
    def release(self, connection: any, path: str) -> None:
        """
        Return connection to pool.
        
        Args:
            connection: Connection to release
            path: PLC path
        """
        with self._lock:
            self._active_connections -= 1
            
            key = self._parse_path(path)
            self._connection_count_by_plc[key] = \
                max(0, self._connection_count_by_plc.get(key, 1) - 1)
            
            self.stats['total_released'] += 1
            
            # Health check before returning to pool
            if not self._is_healthy(connection):
                self._close_connection(connection)
                logger.debug(f"Connection to {path} failed health check - closed")
                return
            
            # Check per-PLC pool limit
            if key not in self._pool:
                self._pool[key] = []
            
            if len(self._pool[key]) < self.max_size:
                # Return to pool with timestamp
                self._pool[key].append((connection, time.time()))
                logger.debug(
                    f"Returned connection to pool for {path}. "
                    f"Pool size: {len(self._pool[key])}/{self.max_size}"
                )
            else:
                # Pool full - close connection
                self._close_connection(connection)
                logger.debug(f"Pool full for {path} - closed connection")
    
    @contextmanager
    def acquire_context(self, path: str):
        """
        Context manager for acquiring/releasing connections.
        
        Usage:
            with pool.acquire_context('192.168.1.10') as plc:
                value = plc.read('MyTag')
        """
        conn = self.acquire(path)
        try:
            yield conn
        finally:
            self.release(conn, path)
    
    def _parse_path(self, path: str) -> Tuple[str, Optional[int]]:
        """
        Parse PLC path into (ip, slot) tuple.
        
        Args:
            path: Path like '192.168.1.10' or '192.168.1.10/1'
            
        Returns:
            (ip, slot) tuple
        """
        parts = path.split('/')
        ip = parts[0]
        slot = int(parts[1]) if len(parts) > 1 else None
        return (ip, slot)
    
    def _is_healthy(self, connection: any) -> bool:
        """
        Lightweight health check.
        
        IMPORTANT: Does NOT call get_plc_info() to avoid PLC load.
        Only checks socket state.
        
        Args:
            connection: Connection to check
            
        Returns:
            True if healthy, False otherwise
        """
        try:
            # Check if connection object exists and has connected property
            if connection is None:
                return False
            
            # Check if has connected property (duck typing)
            if hasattr(connection, 'connected'):
                return connection.connected
            
            # Check if socket exists and is connected
            if hasattr(connection, '_sock') and connection._sock:
                return True
            
            return False
            
        except Exception as e:
            logger.debug(f"Health check failed: {e}")
            return False
    
    def _create_connection(self, path: str) -> any:
        """
        Create new connection to PLC.
        
        Args:
            path: PLC path
            
        Returns:
            New LogixDriver instance
            
        Raises:
            CommError: If connection fails
        """
        # Import here to avoid circular dependency
        from .enhanced_logix_driver import EnhancedLogixDriver

        try:
            # Create connection with tag upload so reads resolve correctly
            conn = EnhancedLogixDriver(path, init_tags=True)
            conn.open()
            return conn
        except Exception as e:
            raise CommError(f"Failed to create connection to {path}: {e}") from e
    
    def _close_connection(self, connection: any) -> None:
        """
        Safely close a connection.
        
        Args:
            connection: Connection to close
        """
        try:
            if connection and hasattr(connection, 'close'):
                connection.close()
            self.stats['total_closed'] += 1
        except Exception as e:
            logger.debug(f"Error closing connection: {e}")
    
    def _cleanup_idle_connections(self) -> None:
        """Remove idle connections that have exceeded timeout."""
        with self._lock:
            now = time.time()
            closed_count = 0
            
            for key, connections in list(self._pool.items()):
                # Filter out idle connections
                active = []
                for conn, last_used in connections:
                    if now - last_used > self.idle_timeout:
                        self._close_connection(conn)
                        closed_count += 1
                    else:
                        active.append((conn, last_used))
                
                if active:
                    self._pool[key] = active
                else:
                    del self._pool[key]
            
            if closed_count > 0:
                logger.info(f"Cleaned up {closed_count} idle connections")
    
    def _start_cleanup_thread(self) -> None:
        """Start background thread for cleaning idle connections."""
        def cleanup_loop():
            while not self._stop_cleanup.wait(self.health_check_interval):
                try:
                    self._cleanup_idle_connections()
                except Exception as e:
                    logger.error(f"Error in cleanup thread: {e}")
        
        self._cleanup_thread = threading.Thread(target=cleanup_loop, daemon=True)
        self._cleanup_thread.start()
        logger.debug("Cleanup thread started")
    
    def get_stats(self) -> Dict[str, any]:
        """
        Get pool statistics.
        
        Returns:
            Dict with pool metrics
        """
        with self._lock:
            total_pooled = sum(len(conns) for conns in self._pool.values())
            
            return {
                **self.stats,
                'active_connections': self._active_connections,
                'pooled_connections': total_pooled,
                'total_connections': self._active_connections + total_pooled,
                'max_global': self.max_global_connections,
                'pool_utilization': self._active_connections / self.max_global_connections,
                'plcs_in_pool': len(self._pool),
            }
    
    def close_all(self) -> None:
        """Close all pooled connections and stop cleanup thread."""
        logger.info("Closing all connections in pool")
        
        # Stop cleanup thread
        self._stop_cleanup.set()
        if self._cleanup_thread:
            self._cleanup_thread.join(timeout=5)
        
        # Close all pooled connections
        with self._lock:
            for key, connections in self._pool.items():
                for conn, _ in connections:
                    self._close_connection(conn)
            
            self._pool.clear()
            self._connection_count_by_plc.clear()
            self._active_connections = 0
        
        logger.info("All connections closed")
    
    def __del__(self):
        """Cleanup on deletion."""
        try:
            self.close_all()
        except:
            pass
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close_all()
        return False

